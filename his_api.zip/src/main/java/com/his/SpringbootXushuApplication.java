package com.his;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootXushuApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootXushuApplication.class, args);
    }

}
