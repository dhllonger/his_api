package com.xushu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootXushuApplicationTests {

    @Test
    void contextLoads() {
    }

}
